// Navbar and overlay toggle

const navBar = document.querySelector('.nav_wrapper');
const burgerIcon = document.querySelector('.nav_burgerIcon');
const overlay = document.querySelector('.overlay_trigger');

// Navbar icon toggle
burgerIcon.addEventListener('click', function(){
    navBar.classList.toggle('is-open')
    overlay.classList.toggle('open')
})
// Overlay toggle
overlay.addEventListener('click', function(){
    navBar.classList.remove('is-open')
    overlay.classList.toggle('open')
})